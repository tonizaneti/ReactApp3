import React, {useState}  from "react";
import {StyleSheet, View} from "react-native"
import Input from "../components/form/Input"

const HomeScreen = ()=> {
    const [stateNome, setStateNome]=useState("");
    return(
        <View style= {styles.viewStyle}>
            <Input label="Nome" onChange={(text)=>setStateNome(text)} initialValue={""} />
        </View>
    )
} 

export default HomeScreen;
const styles = StyleSheet.create({
    viewStyle:{
        flex:1,
        alignItems:"stretch",
        justifyContent: "flex-start"
    }
})
